document.write('<h1>Hello from hello.js');
